# SmartTutor — Final Year Project Demo
SmartTutor demonstrates an AI pipeline combining data analysis, ML model training, optimization scheduling, and chatbot/LLM integration.
